#!/usr/bin/env python
# coding: utf-8

# # Question 1

# In[461]:


#Komal MT19124
#Instructions:
#1. Please put the 5 folders in Data folder created in the directory having this pynb file and other neceesary files attached


# In[462]:


from nltk.corpus import stopwords
import statistics
import numpy as np
from sklearn.manifold import TSNE
from operator import add,sub
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize
import os
import matplotlib.pyplot as plt 
import pickle
import re
from natsort import natsorted
import string
import collections
from num2words import num2words
import math
import numpy as np
import numpy as np
np_load_old = np.load
np.load = lambda *a,**k: np_load_old(*a, allow_pickle=True, **k)


# In[463]:


#Below are functions of preocessing steps for document and query
def readFile(filename):
    file = open(filename, 'r',encoding ="ascii", errors ="surrogateescape")
    document=file.read()
    file.close()
    return document
def whitespaceRemoval(document):
    return document.strip()
def stopWordsRemoval(tokens):
    stop_words=set(stopwords.words('english'))
    token_list=[token for token in tokens if not token in stop_words]
    return token_list
def puntuationsRemoval(document):
    table = str.maketrans('', '', string.punctuation)
    document = document.translate(table)
    return document
def tokenization(document):
    token_list=word_tokenize(document)
    return token_list
def lowerCase(tokens):
    token_list=[token.lower() for token in tokens]
    return token_list
def porterStemmer(tokens):
    ps=PorterStemmer()
    token_list=[ps.stem(token) for token in tokens]
    return token_list
def numbersremoval(document):
    document=re.sub(r'\d+','',document)
    return document
def numbersToWords(document):
    temp = re.findall(r'\d+', document) 
    res = list(map(int, temp)) 
    s=""
    for i in res:
        s=s+num2words(i)+" "
    return s;


# In[464]:


#preprocessing steps applied to document and query
def documentToTerms(document):
    token_list=[]
    #print("Number To words Convertion")
    string_of_numbers=numbersToWords(document)
    #print(string_of_numbers)
    document=document+" "+string_of_numbers
    #print(document)
    #Whitespace removal
    #print("Whitespace removal")
    document=whitespaceRemoval(document)
    #Punctuations Removal
    #print("Puntuations removal")
    document=puntuationsRemoval(document)
#     #removing numbers
    document=numbersremoval(document)
#     #print("Removal of Numbers")
    #print(document)
    #tokenization
    #print("Tokenization")
    token_list=tokenization(document)
#     #stop words removal
    #print("Stop Words Removal")
    #token_list=stopWordsRemoval(token_list)
    #print(token_list)
    #lower Case conversion
    #print("LowerCase Conversion")
    token_list=lowerCase(token_list)
    #print(token_list)
    #stemming
    #print("Stemming")
    token_list=porterStemmer(token_list)
    #print(token_list)
    return token_list


# In[465]:


#Buidling inverted index
def invertedIndex(terms,document_id,vocab_id):
    for term in terms:
        if term in index:
            if(document_id in index[term][1]):
                index[term][1][document_id]+=1
            else:
                index[term][0]+=1
                index[term][1][document_id]=1
        else:
            vocab_id+=1
            vocab[vocab_id]=term
            index[term]=[]
            index[term].append(1)
            index[term].append({})
            index[term][1][document_id]=1
    return vocab_id


# In[466]:


# #Main function for creating the index
# folders=natsorted(os.listdir("Data/"))
# #folders=['comp.graphics']
# document_details={} #storing details per document id
# vocab={} #storig vocan terms and id
# index={} #index for storing term and document
# doc_id=-1
# vocab_id=-1
# for folder in folders:
#     fpath='Data/'+ folder
#     if(os.path.isdir(fpath)):
#         file_names=natsorted(os.listdir("Data/" + folder))
#         #file_names=["37261"]
#         for file_name in file_names:
#             #reading the document
#             doc_id+=1
#             document_details[doc_id]=[]
#             document_details[doc_id].append(folder)
#             document_details[doc_id].append(file_name)
#             document=readFile("Data/" + folder+"/"+file_name)
#             #print(document)
#             terms=list(documentToTerms(document))
#             #inverted index prepration
#             #print("Inverted Index Formation")
#             vocab_id=invertedIndex(terms,doc_id,vocab_id)
# doc_id+=1
# vocab_id+=1
# print("Inverted Index Formation")
# print(index)


# In[467]:


#saving the files
# with open('index.pickle', 'wb') as handle:
#     pickle.dump(index, handle, protocol=pickle.HIGHEST_PROTOCOL)
    
# with open('document_details.pickle', 'wb') as handle:
#     pickle.dump(document_details, handle, protocol=pickle.HIGHEST_PROTOCOL)
    
# with open('vocab.pickle', 'wb') as handle:
#     pickle.dump(vocab, handle, protocol=pickle.HIGHEST_PROTOCOL)

#loading the files
with open('index.pickle', 'rb') as handle:
    index = pickle.load(handle)
with open('document_details.pickle', 'rb') as handle:
    document_details = pickle.load(handle)
with open('vocab.pickle', 'rb') as handle:
    vocab = pickle.load(handle)

doc_id=len(document_details)
vocab_id=len(vocab)


# In[468]:


print("No of documents:",len(document_details))
print("Vocab length:",len(vocab))


# In[469]:


def lengthDocuments(): #calaclates the length of each documents and stores in length
    length=([0 for i in range(doc_id)]) #storing tf
    for term,posting in index.items():
        idf=math.log(doc_id/posting[0])
        for document,frequency in posting[1].items():
            tf=1+math.log(frequency)
            length[document]+=round(tf*idf*tf*idf,4)
    return length


# In[470]:


def displayOld(score,k):#displaying to k documents
    if k<=len(score):
        print("Top "+str(k)+" items are:")
        print(["Doc id:"+str(score[i][0])+" Document:"+str(document_details[score[i][0]])+" Score: "+str(round(score[i][1],4)) for i in range(k)])
    else:
        print("Top ",len(score)," items are:")
        print(["Doc id:"+str(score[i][0])+" Document:"+str(document_details[score[i][0]])+" Score: "+str(round(score[i][1],4)) for i in range(len(score))])


# In[471]:


def cosineSimilairity(length): #performs cosine similarity assuming query vector is 1 for term present in query i.e fast cosine
    score=[]
    score=([[0,i] for i in range(doc_id)])
    for term in query:
        if term in index:
            idf=math.log(doc_id/index[term][0])
            for document,frequency in index[term][1].items():
                tf=1+math.log(frequency)
                score[document][0]+=round(tf*idf,4) 
    score_res=([[i,score[i][0]/length[i]] for i in range(doc_id)])
    return score_res


# In[472]:


query="Population 1 billion"
k=20
query=documentToTerms(query)
print(query)
length=lengthDocuments()
length=([round(math.sqrt(x),4) for x in length])
score=cosineSimilairity(length)
score.sort(key = lambda x: x[1],reverse=True)
displayOld(score,k)


# # Question 2

# In[473]:


# all work raleted to query processing
#Assumption : words not in query are ommited and not included in vocab

def queryToVector(query): #forming query vector from query.
    query_original=[0 for i in range(len(vocab))]
    res = dict((v,k) for k,v in vocab.items())
    for key,value in query.items():
        if(key in res):
            query_original[res[key]]=value
    return query_original
    
def tfidfQuery(query_dict): # calcluting tfidf of query terms
    for key,value in query_dict.items():
        tf=1+math.log(value)
        idf=math.log(doc_id/index[key][0]) if key in index else 0
        query_dict[key]=round(tf*idf,4)
    return query_dict

def queryWork(query): # all major work w.r.t query
    query=documentToTerms(query) #preprocessing query
    query_dict={} # calclating tf for query vector
    for term in query:
        if term in query_dict:
            query_dict[term]+=1
        else:
            query_dict[term]=1
    query_dict=tfidfQuery(query_dict)
    query_vector=queryToVector(query_dict)
    return query_vector


# In[474]:


def display(score,k,relvant):#displaying to k documents
    result=set()
    if k<=len(score):
        result=[score[i] for i in range(k)]
    else:
        result=[score[i] for i in range(k)]
    count=1
    asterisk_doc=set()
    for i in result:
        if(i[0] in relvant):
            print(str(count)," *   Doc id:",str(i[0]),"  Document: ",document_details[i[0]]," Score:",str(round(i[1],4)))
            asterisk_doc.add(i[0])
        else:
            print(str(count),"Doc id:",str(i[0]),"  Document: ",document_details[i[0]]," Score:",str(round(i[1],4)))
        count+=1
    return result,asterisk_doc


# In[475]:


def cosineSimilairityNew(query_updated,length):
    score=[]
    score=([[0,i] for i in range(doc_id)])
    temp=[[i,e] for i,e in enumerate(query_updated) if e != 0]
    for i,e in temp:
        term=vocab[i]
        if term in index:
            idf=math.log(doc_id/index[term][0])
            for document,frequency in index[term][1].items():
                tf=1+math.log(frequency)
                score[document][0]+=round(e*tf*idf,4)  #wq*tf*idf
    score_res=([[i,score[i][0]/length[i]] for i in range(doc_id)])
    return score_res


# In[476]:


def documentToVector(document_id): #converting a partuclar docuemnent to vector form
    doc_vector=[0 for i in range(len(vocab))]
    res = dict((v,k) for k,v in vocab.items())
    for key,value in index.items():
        idf=math.log(doc_id/index[key][0])
        if(document_id in value[1]):
            tf=1+math.log(value[1][document_id])
            doc_vector[res[key]]=round(tf*idf,4)
    return doc_vector


# In[477]:


def updateQuery(relevant,non_relevant,query,a,b,c):
    centroid_relevant=[0 for i in range(len(vocab))]
    centroid_irrelevant=[0 for i in range(len(vocab))]
    for i in relevant:
        centroid_relevant=list( map(add, centroid_relevant, i) )
    centroid_relevant=[(b*x)/len(relevant) for x in centroid_relevant]
    for i in non_relevant:
        centroid_irrelevant=list( map(add, centroid_irrelevant,i) )
    centroid_irrelevant=[(c*x)/len(non_relevant) for x in centroid_irrelevant]
    query=[a*x for x in query]
    query_updated= list(map(add,query,list( map(sub, centroid_relevant, centroid_irrelevant) )))
    query_updated=[round(x,4) for x in query_updated]
    query_updated = [0 if i < 0 else i for i in query_updated] #negative terms are set to 0
    return query_updated


# In[478]:


def tsne(relevant,irrelavant, query_vector):
    tsne = TSNE(n_components=2, random_state=0)
    feature_vector = []
    labels = []
    for i in relevant:
        feature_vector.append(i)
        labels.append(0)
    for i in irrelavant:
        feature_vector.append(i)
        labels.append(1)
    feature_vector.append(query_vector)
    labels.append(2)
    transformed_data = tsne.fit_transform(np.array(feature_vector))
    k = np.array(transformed_data)
    t = ("Relevant", "Non-Relevant", "Query")
    plt.scatter(k[:, 0], k[:, 1], c=labels, label="Violet-R, Aqua-NR")
    plt.title("Rocchio Algorithm")
    plt.legend()
    plt.grid(True)
    plt.show()


# In[479]:


def plottingPrecisionRecall(x,y):
    plt.plot(x, y) 
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.show()


# In[480]:


def calculatingPrecisionRecallMAP(score,ground_truth,k):
    result=set()
    recall=[0]
    precision=[1]
    temp=0 #count of relevant uptil now
    map_value=0
    count=0
    if k<=len(score):
        result=[x[0] for x in score[0:k]]
    else:
        result=[x[0] for x in score[0:len(score)]]
    for i in result:
        count+=1
        if(document_details[i][0]==ground_truth):
            temp+=1
            map_value+=temp/count
        precision.append(temp/count)
        recall.append(temp/1000)
    map_value=map_value/temp
    plottingPrecisionRecall(recall,precision)
    return map_value


# In[481]:


def intialResult(query_vector):
    score=cosineSimilairityNew(query_vector,length)
    score.sort(key = lambda x: x[1],reverse=True)
    print("Documents from intial query")
    result,asterisk_doc=display(score,k,{})
    result=set([i[0] for i in result])
    return result,asterisk_doc


# In[482]:


def RocchiooAlgorithm(query,a,b,c,k,p,ground_truth,length,result,asterisk_doc):
    relevant=set() #storing relavnt documenst
    irrelevant=set() #storing irrerlavant documents
    query_vector=queryWork(query) #processing query to query vector
    p=(int)((p*k)/100) # no of relavant doc to be marked at each iteartion
    map_=[]
    for m in range(1,4):
        print("Feedback Iteration ",m)
        print("Enter ",p," relevant documents id of ",ground_truth)
        temp=input()
        temp=set(int(i) for i in temp.split(" "))
        if(len(temp)<p):
            temp=set(list(temp)[0:len(temp)])
        else:
            temp=set(list(temp)[0:p])
        relevant=temp
        print("Marked Relevant Docuemnst:",relevant)
        irrelevant=result.difference(relevant.union(asterisk_doc))
        print("Marked Irrelevant Docuemnst::",irrelevant)
        vector_relevant=[] # storing relevant documents vector 
        vector_irrelevant=[] #storing irrelevant documenst vector
        for i in relevant:
            vector_relevant.append(documentToVector(i))
        for i in irrelevant:
            vector_irrelevant.append(documentToVector(i))
        query_vector=updateQuery(vector_relevant,vector_irrelevant,query_vector,a,b,c)
        score=cosineSimilairityNew(query_vector,length)
        score.sort(key = lambda x: x[1],reverse=True)
        result,asterisk_doc=display(score,k,relevant)
        result=set([i[0] for i in result])
        tsne(vector_relevant,vector_irrelevant,query_vector)
        map_.append(calculatingPrecisionRecallMAP(score,ground_truth,k))
    return map_


# In[483]:


def mapCalulcation(map_overall,no_query):
    sum_=0
    no_iterations=len(map_overall[0])
    for i in range(no_iterations):
        sum_=sum(j[i] for j in map_overall)
        print("At ",i+1,"iteration MAP is:")
        print(sum_/no_query)


# # Part A/B/C/D/E/F

# In[ ]:


# Relavant documents input for first query
# 2040 2864 2753 2477 2962 2760 2234 2848 2421 2661
# 2878 2543 2526 2983 2859 2683 2952 2567 2850 2914
# 2848 2864 2962 2693 2664 2692 2682 2755 2908 2430

# Relavant documents input for second query
# 4426 4622 4638 4989 4432 4598 4928 4701 4102 4763
# 4226 4472 4580 4317 4299 4378 4305 4320 4686 4361
# 4580 4426 4299 4305 4378 4472 4317 4360 4320 4828

# Relavant documents input for third query
# 2010 2011 2730 2794 2097 2115 2046 2200 2770 2424
# 2118 2114 2117 2543 2459 2404 2646 2698 2644 2598
# 2115 2526 2487 2643 2486 2483 2645 2395 2914 2693


# In[484]:


a=1  # weights of Rocchio algo
b=0.75
c=0.25
k=100 #top k documensts
p=10
query_list=['Pretty good opinions on biochemistry machines','Scientific tools for preserving rights and body','Frequently asked questions on State-of-the-art visualisation tools']
ground_truth_list=['sci.med','talk.politics.misc','sci.med']
map_overall=[]
for i in range(len(query_list)):
    query=query_list[i]
    ground_truth=ground_truth_list[i]
    print("Query:",query," Ground Truth:",ground_truth)
    query_vector=queryWork(query)
    result,asterisk_doc=intialResult(query_vector)
    map_=RocchiooAlgorithm(query,a,b,c,k,p,ground_truth,length,result,asterisk_doc)
    map_overall.append(map_)

mapCalulcation(map_overall,len(query_list))

