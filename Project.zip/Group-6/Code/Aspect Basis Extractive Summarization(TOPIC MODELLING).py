#!/usr/bin/env python
# coding: utf-8

# # Reading data

# In[92]:


import pandas as pd
import matplotlib.pyplot as plt 
from nltk.corpus import wordnet 
import nltk
import csv
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from nltk.corpus import sentiwordnet as swn
from nltk.tokenize import sent_tokenize, word_tokenize
import os
import re
import string
import pickle



import numpy as np
from sklearn.feature_extraction.text import CountVectorizer,TfidfVectorizer
from sklearn.decomposition import LatentDirichletAllocation
import mglearn


# In[93]:


def helper():
    datalaptop=pd.read_csv("/Users/komal/Documents/Second_Sem/Information-Retrieval/Project/Extractive/IR_Mid/Data/Laptop_Final_data.csv")
    datalaptop=datalaptop.fillna("None")
    datalaptop.product_id=datalaptop.product_id.astype(int)
    datarestaurant = pd.read_csv("Data/Restaurants_Final_data.csv")
    datarestaurant=datarestaurant.fillna("None")
    datarestaurant.product_id=datarestaurant.product_id.astype(int)
    return datalaptop,datarestaurant


# In[94]:


def readFile(filename):
    data=pd.read_csv("Data/"+filename)
    data=data.fillna("None")
    data.product_id=data.product_id.astype(int)
    print("Length of data:",len(data))
    print("Data head:")
    return data
#print(data.head())


# In[95]:


def productSelection(product):
    datalaptop,datarestaurant=helper()
    if(product=='laptop'):
        #data=readFile('laptop_final_data.csv')
        data = datalaptop
        #print("Length of data:",len(data))
        #print("Data head:")
    elif(product=='restaurant'):
        #data=readFile('Restaurants_Final_data.csv')
        data = datarestaurant
        #print("Length of data:",len(data))
        #print("Data head:")
    return data


# # Abbreviating

# In[96]:


abb_dict={'A/D':'Analog-to-Digital',
'ACM':'Association for Computing Machinery',
'AI':'Artificial Intelligence',
'ALGOL':'Algorithic Language',
'ALU':'Arithmetic Logic Unit',
'AMD':'Advanced Micro Devices',
'APRANET':'Advanced Research Project Agency Network',
'ASCII':'American Standard Code for Information Interchange',
'BCD':'Binary Coded Decimal',
'BIOS':'Basic Input Output System',
'BPI':'Bytes Per Inch',
'CAD':'Computer Aided Design',
'CAE':'Computer Aided Engineering',
'CASE':'Computer Aided Software Engineering',
'CD':'Compact Disk',
'CDC':'Control Data Corporation',
'CD-R':'CD-Recordable',
'CD-ROM':'Compact Disk Read Only Memory',
'CD-RW':'CD Read/Write',
'CL':'Command Language',
'CLI':'Command Line Interface',
'COBOL':'Common Business Oriented',
'CODASYL':'Conference On Data Systems',
'CPU':'Central Processing Unit',
'CRT':'Cathode Ray Tube',
'D/A':'Digital-to-Analog',
'DAT':'Digital Audio Tape',
'DBMS':'Data Base Management System',
'DBS':'Demand Based Switching',
'DDL':'Data Definition Language',
'DDS':'Digital Data Storage',
'DEC':'Digital Equipment Corporation',
'DMA':'Direct Memory Access',
'DNA':'Digital Network Architecture',
'DPI':'Dots Per Inch',
'DRAM':'Dynamic RAM',
'DSN':'Distributed Systems Network',
'DTS':'Digital Theater System',
'DVD':'Digital Video/Versatile Disk',
'EBCDIC':'Extended Binary Coded Decimal Interchange Code',
'EDSAC':'Electronic Delay Storage Automatic Calculator',
'EDVAC':'Electronic Discrete Variable Automatic Calculator',
'EFM':'Eight-to-Fourteen Modulation',
'ENIAC':'Electronic Numerical Integrator And Calculator',
'EPG':'Electronic Programming Guide',
'EPIC':'Explicitly Parallel Instruction Computing',
'EPROM':'Erasable Programmable Read-Only Memory',
'FAT':'File Allocation Table',
'FDM':'Frequency Division Multiplexing',
'FEP':'Front End Processor',
'FLOPS':'Floating Point Operations Per Second',
'FM':'Frequency Modulation',
'FMS':'File Management System',
'FORTRAN':'FORmula TRANslation',
'FSK':'Frequency Shift Keying',
'FTP':'File Transfer Protocol',
'GB':'Giga Bytes',
'GFLOPS':'Giga FLOPS',
'GHz':'Giga Hertz',
'GNU':'Gnu Not Unix',
'GPRS':'General Packet Radio Service',
'GSM':'Global System for Mobile communication',
'GUI':'Graphical User Interface',
'HP':'Hewlett Packard',
'HSS':'Hierarchical Storage System',
'HTML':'HyperText Markup Language',
'HTTP':'HyperText Transport Protocol',
'IBM':'International Business Machine',
'IC':'Integrated Circuit',
'IDN':'Integrated Digital Networks',
'IP':'Internet Protocol',
'IrDA':'Infrared Data Association',
'ISDN':'Integrated Services Digital Network',
'ISP':'Internet Service Provider',
'JPEG':'Joint Photographic Experts Group',
'JRE':'Java Runtime Engine',
'JSP':'Java Server Pages',
'KB':'Kilo Bytes',
'KHz':'Kilo Hertz',
'LAN':'Local Area Network',
'LCD':'Liquid Crystal Display',
'LED':'Light Emitting Diode',
'LPM':'Line Per Minute',
'LSI':'Large Scael Integration',
'MAN':'Metropolitan Area Network',
'MAR':'Memory Address Register',
'MB':'Mega Bytes',
'MBR':'Memory Buffer Register',
'MHz':'Mega Hertz',
'MIDI':'Musical Instrument Digital Interface',
'MIPS':'Millions of Instructions Per Second',
'MNP':'Microcom Network Protocol',
'MPEG':'Moving Pictures Experts Group',
'MS-DOS':'MicroSoft Disk Operating System',
'MVT':'Multiprogramming with Variable Tasks',
'NIC':'Network Interface Card',
'NICNET':'National Informatics Center NETwork',
'NOS':'Network Operating System',
'OCR':'Optical Character Recognition',
'OMR':'Optical Mark Reader',
'OS':'Operating System',
'OSI':'Open System Interconnection',
'OSS':'Open Source Software',
'PAN':'Personal Area Network',
'PC':'Personal Computer',
'PDF':'Portable Document Format',
'PDL':'Program Design Language',
'PDP':'Program Data Processor',
'PIP':'Peripheral Interchange Program',
'PROM':'Programmable Read-Only Memory',
'QoS':'Quality of Service',
'RAM':'Random Access Memory',
'ROM':'Read Only Memory',
'SDLC':'Software Development Life Cycle',
'SEQUEL':'Structured English QUEry Language',
'SGML':'Syntax for Generalized Markup Language',
'SIMM':'Single In-line Memory Module',
'SNA':'Systems Network Architecture',
'SNOBOL':'StriNg Oriented and symBOlic Language',
'SQL':'Structured Query Language',
'SRAM':'Static RAM',
'SSI':'Small Scale Integration',
'TB':'Tera Bytes',
'TCP':'Transport Control Protocol',
'TDM':'Time Division Multiplexing',
'UDP':'User Datagram Protocol',
'ULSI':'Ultra Large Scale Integration',
'UPC':'Universal Product Code',
'URL':'Uniform Resource Locator',
'USB':'Universal Serial Bus',
'UTF':'Unicode Transformation Format',
'VAN':'Value Added Network',
'VCR':'Video Cassette Recorder',
'VDT':'Video Display Terminal',
'VGA':'Video Graphics Array',
'VOD':'Video-On-Demand',
'VoIP':'Voice over Internet Protocol',
'VSAT':'Very Small Aperture Terminal',
'WAN':'Wide Area Network',
'WAP':'Wireless Application Protocol',
'WiMAX':'Worldwide Interoperability for Microwave Access',
'WLAN':'Wireless Local Area Network',
'WLL':'Wireless Local Loop',
'WORM':'Write Once Read Many',
'WWW':'World Wide Web',
'XHTML':'eXtensible HyperText Markup Language',
'XML':'eXtensible Markup Language',
'X.400':'Electronic Mail Protocol',
'X.500':'Directory Server Protocol',
'O/S':'Operating System',
'27"':'Inch',
'WT':'Weight',
'OSX':'Operating System',
'OS X':'Operating System',
'OS.X':'Operating System',
'Win7':'Windows 7'}


# In[97]:


def abbreviatedFunc(abb):
    if abb in abb_dict:
        return abb_dict[abb]
    else:
        return abb


# In[98]:


def translator(user_string):
    user_string = user_string.split(" ")
    result = ""
    for _str in user_string:
        # Removing Special Characters.
        _str = re.sub('[^a-zA-Z0-9-_.]', '', _str)
        result+=abbreviatedFunc(_str.upper()).lower()+" "
    return result
    #print(' '.join(user_string))
    
def Replacefunc(review):
    reviewnewlist = []
    reviewlist=review.split(' ')
    for l in reviewlist:
        reviewnewlist.append(translator(l))
        
    return ' '.join(reviewnewlist)


# In[99]:


def preProcess_aspect(aspect):
    aspect=whitespaceRemoval(aspect)
    abb_list = []
    sentences = []  
    for s in aspect.split():
        s = re.sub(r'[!,;\'\n\"#$»%&()*/:;<=>?@[\]^_`{|}~]','',s)
        s = re.sub(r'-',' ',s)
        sentences.append(s.lower())
    finalstring = ' '.join(sentences)
    return finalstring


# In[100]:


def contractionFunc(review):
    contractions={
    "ain't": "am not / are not / is not / has not / have not",
    "aren't": "are not / am not",
    "can't": "cannot",
    "can't've": "cannot have",
    "'cause": "because",
    "could've": "could have",
    "couldn't": "could not",
    "couldn't've": "could not have",
    "didn't": "did not",
    "doesn't": "does not",
    "don't": "do not",
    "hadn't": "had not",
    "hadn't've": "had not have",
    "hasn't": "has not",
    "haven't": "have not",
    "he'd": "he had / he would",
    "he'd've": "he would have",
    "he'll": "he shall / he will",
    "he'll've": "he shall have / he will have",
    "he's": "he has / he is",
    "how'd": "how did",
    "how'd'y": "how do you",
    "how'll": "how will",
    "how's": "how has / how is / how does",
    "i'd": "I had / I would",
    "i'd've": "I would have",
    "i'll": "I shall / I will",
    "i'll've": "I shall have / I will have",
    "i'm": "I am",
    "i've": "I have",
    "isn't": "is not",
    "it'd": "it had / it would",
    "it'd've": "it would have",
    "it'll": "it shall / it will",
    "it'll've": "it shall have / it will have",
    "it's": "it has / it is",
    "let's": "let us",
    "ma'am": "madam",
    "mayn't": "may not",
    "might've": "might have",
    "mightn't": "might not",
    "mightn't've": "might not have",
    "must've": "must have",
    "mustn't": "must not",
    "mustn't've": "must not have",
    "needn't": "need not",
    "needn't've": "need not have",
    "o'clock": "of the clock",
    "oughtn't": "ought not",
    "oughtn't've": "ought not have",
    "shan't": "shall not",
    "sha'n't": "shall not",
    "shan't've": "shall not have",
    "she'd": "she had / she would",
    "she'd've": "she would have",
    "she'll": "she shall / she will",
    "she'll've": "she shall have / she will have",
    "she's": "she has / she is",
    "should've": "should have",
    "shouldn't": "should not",
    "shouldn't've": "should not have",
    "so've": "so have",
    "so's": "so as / so is",
    "that'd": "that would / that had",
    "that'd've": "that would have",
    "that's": "that has / that is",
    "there'd": "there had / there would",
    "there'd've": "there would have",
    "there's": "there has / there is",
    "they'd": "they had / they would",
    "they'd've": "they would have",
    "they'll": "they shall / they will",
    "they'll've": "they shall have / they will have",
    "they're": "they are",
    "they've": "they have",
    "to've": "to have",
    "wasn't": "was not",
    "we'd": "we had / we would",
    "we'd've": "we would have",
    "we'll": "we will",
    "we'll've": "we will have",
    "we're": "we are",
    "we've": "we have",
    "weren't": "were not",
    "what'll": "what shall / what will",
    "what'll've": "what shall have / what will have",
    "what're": "what are",
    "what's": "what has / what is",
    "what've": "what have",
    "when's": "when has / when is",
    "when've": "when have",
    "where'd": "where did",
    "where's": "where has / where is",
    "where've": "where have",
    "who'll": "who shall / who will",
    "who'll've": "who shall have / who will have",
    "who's": "who has / who is",
    "who've": "who have",
    "why's": "why has / why is",
    "why've": "why have",
    "will've": "will have",
    "won't": "will not",
    "won't've": "will not have",
    "would've": "would have",
    "wouldn't": "would not",
    "wouldn't've": "would not have",
    "y'all": "you all",
    "y'all'd": "you all would",
    "y'all'd've": "you all would have",
    "y'all're": "you all are",
    "y'all've": "you all have",
    "you'd": "you had / you would",
    "you'd've": "you would have",
    "you'll": "you shall / you will",
    "you'll've": "you shall have / you will have",
    "you're": "you are",
    "you've": "you have"
    }
    
    review=review.split(" ")
    temp=''
    for i in review:
        if i in contractions:
            temp+=contractions[i]+" "
        else:
            temp+=i+" "
    return temp

def puntuationsRemoval(document):
    table = str.maketrans('', '', string.punctuation)
    document = document.translate(table)
    return document

def readFile(filename):
    file = open(filename, 'r',encoding ="ascii", errors ="surrogateescape")
    document=file.read()
    file.close()
    return document

def remove_header_footer(final_string): 
    new_final_string = "" 
    tokens = final_string.split('\n\n') 
    for token in tokens[1:-1]: 
        new_final_string += token+" "
    return new_final_string 

def puntuationsRemoval(document):
    table = str.maketrans('', '',string.punctuation)
    document = document.translate(table)
    return document

def lowerCase(document):
    document=document.lower()
    return document

def tokenization(document):
    token_list=word_tokenize(document)
    return token_list

def removePunctuationsUsingIsAphha(tokens):
    token_list=[token for token in tokens if token.isalpha()]
    return token_list

def stopWordsRemoval(tokens):
    stop_words=set(stopwords.words('english'))
    token_list=[token for token in tokens if not token in stop_words]
    return token_list

def porterStemmer(tokens):
    ps=PorterStemmer()
    token_list=[ps.stem(token) for token in tokens]
    return token_list

def whitespaceRemoval(document):
    return document.strip()

def lowerCaseTokens(tokens):
    token_list=[token.lower() for token in tokens]
    return token_list


# In[101]:



def datasetAbb(data):
    for i in range(0,len(data)):
        review = data['text'][i]
        review = Replacefunc(review)
        data['text'][i] = review 
        for j in range(1,14):
            aspect = 'Aspect '+str(j)
            aspect_review = data[aspect][i]
            if aspect_review != 'None':
                #print(type(aspect_review))
                #print(aspect_review)
                aspect_review = Replacefunc(aspect_review)
                aspect_review = preProcess_aspect(aspect_review)
                data[aspect][i] = aspect_review
    
    print(data.head())    
    return data


# # User Input Processing

# In[102]:


def stemming(word):
    from nltk.stem import PorterStemmer
    ps = PorterStemmer()
    return ps.stem(word)

def aspectList(data):
    aspect_vocablist = []
    for i in range(1,14):
        aspect = 'Aspect '+str(i)
        for a in data[aspect]:
            if a != 'None':
                aspect_vocablist.append(a)

    aspect_vocablist = list(set(aspect_vocablist))
    
    stemmed_aspects_list = []
    for aspect in aspect_vocablist:
        templist = []
        for i in aspect.split():
            templist.append(stemming(i))
        aspects_stemmed=' '.join(templist)
        stemmed_aspects_list.append(aspects_stemmed)
    
    return stemmed_aspects_list,aspect_vocablist


# # Aspect List Generation

# In[103]:


def apsectListGeneration(query,aspect_vocablist,stemmed_aspects_list):
    synonyms = [] 
    final_vocablist = []
    for q in query.split():
        for syn in wordnet.synsets(q):
            for l in syn.lemmas():
                synonyms.append(l.name())
        synonyms = list(set(synonyms)) 

    for q in query.split():
        if q in aspect_vocablist:
            final_vocablist.append(q)

    if query in aspect_vocablist:
        final_vocablist.append(query)



    for q in query.split():
        if q in stemmed_aspects_list:      #checking in the stemmed list for the query word
            if q not in final_vocablist:
                final_vocablist.append(query)



    for s in synonyms:
        if (s in aspect_vocablist) or (s in stemmed_aspects_list):
            if s not in final_vocablist:
                final_vocablist.append(s)

    final_vocablist = list(set(final_vocablist))
    return final_vocablist


# In[104]:


def query_aspectCreation(query,data):
    stemmed_aspects_list,aspect_vocablist=aspectList(data)
    #print(stemmed_aspects_list)
    #print(aspect_vocablist)
    query=translator(query)
    query=preProcess_aspect(query)
    aspects=apsectListGeneration(query,aspect_vocablist,stemmed_aspects_list)
    print("The aspects:",aspects)
    return aspects


# # Building Positional Inverted Index for all tokens 

# In[105]:


#Prerocessing steps
def preProcessing(review):
    review=lowerCase(review)
    review=contractionFunc(review)
    review=whitespaceRemoval(review)
    review=puntuationsRemoval(review)
    review_tokens=tokenization(review)
    review_tokens=lowerCaseTokens(review_tokens)
    return review_tokens


# In[106]:


def invertedIndex(review_tokens,review_id,index):#Building positional index
    for position,term in enumerate(review_tokens):
        if term in index:
            if(review_id in index[term][1]):
                index[term][1][review_id].append(position)
            else:
                index[term][1][review_id]=[position]
                index[term][0]+=1
        else:
            index[term]=[]
            index[term].append(1)
            index[term].append({})
            index[term][1][review_id]=[position]  
    return index


# In[107]:


def invertedindexCreation(data):  
    index={} #positional index
    review_list={} #stores review and review_id
    for ind in data.index: 
        review=data['text'][ind]
        review_tokens=preProcessing(review) #prerocessing each review
        review_id=data['product_id'][ind]
        review_list[review_id]=review_tokens
        index = invertedIndex(review_tokens,review_id,index) #positional index creation
    #print("Positional Inverted Index Formation")
    #print(index)
    return index,review_list


# # Finding postion of aspect in review

# In[108]:


def phraseQuery(phrase,index):#finds the position of the aspects position in the review
    temp1={}
    temp2={}
    if(not phrase[0] in index):
        print("Not found!!")
        return
    for document,positions in index[phrase[0]][1].items():
        temp1[document]=positions
    
    for counter in range(1,len(phrase)):
        word=phrase[counter]
        if(not word in index):
            print("Not Found!!")
            return
        for document,positions in index[word][1].items():
            if(document in temp1):
                for position in positions:
                    if(position-1 in temp1[document]):
                        if(document in temp2):
                            temp2[document].append(position)
                        else:
                            temp2[document]=[position]
        if(len(temp2)==0):
            print("Not Found!!")
            return
        temp1=temp2.copy()
        temp2={}
    return temp1


# # Finding ngrams relevant to check polarity of the aspect

# In[109]:


def posTagging(ngrams):
    grammar = ('''
                    AJ+AV: {(<RB>|<RBR>|<RBS>)(<JJ>|<JJS>|<JJR>)}
                    AJ:{(<JJ>|<JJS>|<JJR>)}
                ''')
    chunkParser = nltk.RegexpParser(grammar)
    tagged = nltk.pos_tag(ngrams)
    tree = chunkParser.parse(tagged)
#     print("The POS tree:")
#     print(tree)
    polar_candidates=[]            
    for elem in tree:
        if isinstance(elem, nltk.Tree):
            temp = ""
            for (text, tag) in elem:
                temp += text+" "
            polar_candidates.append(whitespaceRemoval(temp))
    return polar_candidates


# In[110]:


def fullGrams(aspect_review,grams,aspect_pos,aspect):
    final_review=''
    if aspect_pos-grams<0:
        for i in aspect_review[0:aspect_pos]:
            final_review+=str(i)+" "
    else:
        for i in aspect_review[aspect_pos-grams:aspect_pos]:
            final_review+=str(i)+" "
    for i in aspect:
        final_review+=str(i)+" "
        
    aspect_pos=aspect_pos+len(aspect)-1
    if aspect_pos+grams>=len(aspect_review):
        for i in aspect_review[aspect_pos+1:len(aspect_review)]:
            final_review+=str(i)+" "
    else:
        ngrams=aspect_review[aspect_pos+1:aspect_pos+grams]
        for i in aspect_review[aspect_pos+1:aspect_pos+grams]:
            final_review+=str(i)+" "
    return final_review


# In[111]:


def polarityCandidatesLeft(aspect_pos,aspect_review,grams):
    if aspect_pos-grams<0:
        ngrams=aspect_review[0:aspect_pos]
    else:
        ngrams=aspect_review[aspect_pos-grams:aspect_pos]
    #print("The ngrams left are:",ngrams)
    polar_candidates=[]
    if(len(ngrams)!=0):
        polar_candidates=posTagging(ngrams)
    return polar_candidates


# In[112]:


def polarityCandidatesRight(aspect_pos,aspect_review,grams):
    if aspect_pos+grams>=len(aspect_review):
        ngrams=aspect_review[aspect_pos+1:len(aspect_review)]
    else:
        ngrams=aspect_review[aspect_pos+1:aspect_pos+grams]
    #print("The ngrams right are:",ngrams)
    polar_candidates=[]
    if(len(ngrams)!=0):
        polar_candidates=posTagging(ngrams)
    return polar_candidates


# # Score calculation to club sentence to positive and negative

# In[113]:


def sentiwordNetScore(word,POS):#referring sysnsetWordNet to get the polarity of word
    try:
        temp=word+"."+POS+"."+"01"
        word=swn.senti_synset(temp)
        return word.pos_score(),word.neg_score(),word.obj_score()
    except:
        return 0,0,0


# In[114]:


def scoring(attribute):
    attribute=tokenization(attribute)

    if(len(attribute)==1):#Only adjective
        adjective=attribute[0]
        adjective_score=sentiwordNetScore(adjective,'a')
        #print("Adjective Score:",adjective_score)
        if(adjective_score[0]>=adjective_score[1]):
                return adjective_score[0],'positive'
        elif(adjective_score[0]<adjective_score[1]):
                return adjective_score[1],'negative'
    elif(len(attribute)==2):#Adjective+Adverb
        adverb=attribute[0]
        adjective=attribute[1]
        adverb_score=sentiwordNetScore(adverb,'r')
        adjective_score=sentiwordNetScore(adjective,'a')
        #print("Adjective Score attached to adverb:",adjective_score)
        #print("Adverb Score:",adverb_score)
        if(adverb_score[0]>=adverb_score[1]):  #affirmation
            if(adjective_score[0]>=adjective_score[1]):
                return adjective_score[0]+0.35*adverb_score[0],'positive'
            elif(adjective_score[0]<adjective_score[1]):
                return adjective_score[1]+0.35*adverb_score[0],'negative'
        elif(adverb_score[0]<adverb_score[1]): #negation
            if(adjective_score[0]>=adjective_score[1]):
                return adjective_score[0]-0.35*adverb_score[1],'positive'
            elif(adjective_score[0]<adjective_score[1]):
                return adjective_score[1]-0.35*adverb_score[1],'negative'


# In[115]:


def polarityScore(values):
    score=[0,0]
    for value in values[0]:
        total_score,type_of_score=scoring(value)
        if(type_of_score=='positive'):
            score[0]+=total_score
        elif(type_of_score=='negative'):
            score[1]+=total_score       
    for value in values[1]:
        total_score,type_of_score=scoring(value)
        if(type_of_score=='positive'):
            score[0]+=total_score
        elif(type_of_score=='negative'):
            score[1]+=total_score 
    #print("pos:",score[0],"neg",score[1])
    if(score[0]>score[1]):
        return 'positive',score[0]-score[1]
    elif(score[0]<score[1]):
        #print("---------------------------------------------------------------------negative")
        return 'negative',score[1]-score[0]
    else:
        return 'neutral',0


# In[116]:


def tokenToString(tokens):
    temp=""
    for i in tokens:
        temp+=str(i)+" "
    return whitespaceRemoval(temp)


# In[117]:


def addToDict(polarity_chart,type_polarity,aspect,key):
    aspect=tokenToString(aspect)
    if(key in polarity_chart):
        temp=[]
        temp.append(aspect)
        temp.append(type_polarity)
        polarity_chart[key].append(temp)
    else:
        polarity_chart[key]=[]
        temp=[]
        temp.append(aspect)
        temp.append(type_polarity)
        polarity_chart[key].append(temp)
    return polarity_chart


# # Measures for testing the model

# In[118]:


def accuracy(polarity_chart,data):
    total=0
    FP=0
    FN=0
    TP=0
    TN=0
    for key,values in polarity_chart.items():
        ind=data.index[data['product_id'] == key].tolist()[0]
        for i in range(2,len(data.columns),2):
            if i<len(data.columns):
                review=data.iloc[ind,i]
                for value in values:
                    if(value[0]==review):
                        sign=data.iloc[ind,i+1]
                        if(value[1]==sign):
                            if(sign=='positive'):
                                TP+=1
                            else:
                                TN+=1
                        elif(value[1]!=sign):
                            if(sign=='positive'):
                                FN+=1
                            elif(sign=='negative'):
                                FP+=1
                            elif(sign=='neutral'):
                                TP+=1
                                TN+=1
    #print(TP,TN,FP,FN)                            
    precision=round(TP/(TP+FP),4)
    recall=round(TP/(TP+FN),4)
    accuracy=round((TP+TN)/(TP+FP+TN+FN),4)
    f_score=round((2*precision*recall)/(precision+recall),4)
    #print("Precison:",precision," Recall:",recall," F-score:",f_score," Accuracy:",accuracy)
    return f_score


# In[119]:


# def plot(X,Y):
#     plt.plot(X, Y)
#     plt.xlabel('Number of grams') 
#     # naming the y axis 
#     plt.ylabel('F1 score') 
#     plt.title('Number of grams vs F1 score') 
#     plt.show()


# In[120]:


def plot(X,y):#the plotting fucntion in general
    Xi = list(range(len(X)))
    plt.xticks(Xi, X)
    plt.plot(Xi,y,marker='o') 
    plt.xlabel('Number of grams') 
    plt.ylabel('F1 score') 
    plt.title('Number of grams vs F1 score') 
    plt.legend()
    plt.show()


# # Main

# In[137]:


def cruxFunc(index,review_list,aspects,data):

    X=[]
    Y=[]
    for no_of_grams in range(9,10):
        polarity_chart={}
        positive_review=[]
        negative_review=[]
        sum=0
        for aspect in aspects:
            #print("The aspect is:",aspect)
            aspect=preProcessing(aspect) #preprocess the aspect
            result=phraseQuery(aspect,index)  #getting postion of aspect in the review e.g in "the battery life" pos is 2 .Position of Second last word in aspect
            if(result is not None):
                for key,values in result.items(): # result has review is and the position of aspect
                    document_polar_word=[] # stores opinion word for the aspect in a review
                    aspect_review=review_list[key]
                    for value in values:
                        pos_aspect=(value+1)-len(aspect)
                        #print("Position of aspect:",aspect," in review:",aspect_review," is:",pos_aspect)
                        polar_candidates=polarityCandidatesLeft(pos_aspect,aspect_review,no_of_grams)
                        document_polar_word.append(polar_candidates)
                        polar_candidates=polarityCandidatesRight(pos_aspect+len(aspect)-1,aspect_review,no_of_grams)
                        document_polar_word.append(polar_candidates)
    #                 print("Polar words for aspect ",aspect," in review ",key," is:",document_polar_word)
                    type_polarity,score=polarityScore(document_polar_word)#score for each polar term
                    #print(score)
                    polarity_chart=addToDict(polarity_chart,type_polarity,aspect,key)
        #             if(type_polarity==1):
        #                 print("polarity of review ",aspect_review," is:Postive")
        #             elif(type_polarity==-1):
        #                 print("polarity of review ",aspect_review," is:Negative")
                    for value in values:
                        pos_aspect=(value+1)-len(aspect)
                        if(type_polarity=='positive' or type_polarity=='neutral'):
                            temp=fullGrams(aspect_review,no_of_grams,pos_aspect,aspect)
                            if(len(temp)!=0):
                                positive_review.append(temp)
                        if(type_polarity=='negative' or type_polarity=='neutral'):
                            temp=fullGrams(aspect_review,no_of_grams,pos_aspect,aspect)
                            if(len(temp)!=0):
                                negative_review.append(temp)
#                 print("Positive Review for aspect",aspect)
#                 print(positive_review)
#                 print("Negative Review for aspect",aspect)
#                 print(negative_review)

            else:
                print("No Documents contaning the phrase")
        #X.append(no_of_grams)
        #Y.append(accuracy(polarity_chart,data))
    #print("The polarity Chart is:")
    #print(polarity_chart)
    #plot(X,Y)
    
    return positive_review,negative_review
    


# # GUI

# In[122]:


def list2string(reviews):
    result = ""
    for r in range(len(reviews)):
        result += str(r+1)+'. '+ reviews[r]+'\n'
    return result


# In[221]:


temp=pd.read_csv("/Users/komal/Documents/Second_Sem/Information-Retrieval/Project/Extractive/IR_Mid/Data/Extractive_GT.csv")


# In[222]:


def submitFunc():
    product = items[1].value
    query = items[3].value
    positive_review,negative_review=main(product,query)
    combined_list_temp=positive_review+negative_review
    #print(combined_list_temp)
    length=10
    actual_sum=temp.loc[temp['Aspect'] ==query, 'Actual_Summary'].iloc[0]
     #Topic Modelling Approach
    print(" ")
    print("--------------------------------------------------------------------------------------")
    print("TOPIC MODELLING APPROACH")
    print("--------------------------------------------------------------------------------------")
    model_sum=vectorCreation(combined_list_temp,length)
    evalutionMetrics(actual_sum,model_sum)
    
    
def storeData(db,product):
    if product == 'laptop':
        dbfile = open('AbbreviatedDataLaptop', 'ab') 
    # source, destination 
        pickle.dump(db, dbfile)                      
        dbfile.close() 
    elif(product=='restaurant'):
        dbfile = open('AbbreviatedDataRestaurant', 'ab') 
        # source, destination 
        pickle.dump(db, dbfile)                      
        dbfile.close() 
        
    
def loadData(product):
    if product == 'laptop':
        dbfile = open('AbbreviatedDataLaptop', 'rb')      
        db = pickle.load(dbfile) 
    elif(product=='restaurant'):
        dbfile = open('AbbreviatedDataRestaurant', 'rb')      
        db = pickle.load(dbfile) 
    return db

def main(product,query):
    #print(product,query)
    data = productSelection(product)
    #data = datasetAbb(data)
    #storeData(data,product)
    data=loadData(product)
    aspects=query_aspectCreation(query,data)
    index,review_list=invertedindexCreation(data)
    positive_review,negative_review=cruxFunc(index,review_list,aspects,data)

    items[5].value = list2string(positive_review)
    items[7].value = list2string(negative_review)
    return positive_review,negative_review


# In[213]:


import ipywidgets as widgets
from ipywidgets import interact, interactive, fixed, interact_manual


# In[209]:


items = [widgets.Label(value='Select the product:'),widgets.Dropdown(
    options=['laptop', 'restaurant'],
    value='laptop',
    disabled=False,),widgets.Label(value='Enter aspect of the product: '),widgets.Text(),widgets.Label(value='Positive review: '),widgets.Textarea(),widgets.Label(value='Negative review: '),widgets.Textarea()]
left_box = widgets.VBox([items[0], items[2],items[4],items[6]])
right_box = widgets.VBox([items[1], items[3],items[5],items[7]])
widgets.HBox([left_box, right_box])




# In[220]:


#button = items[5]
button =widgets.Button(
    description='Submit',
    disabled=False,
    
    button_style='', # 'success', 'info', 'warning', 'danger' or ''
    tooltip='Click me',
)
output = widgets.Output()
display(button,output)    #The submit button will print the output here!!
def on_button_clicked(b):
    with output:
        submitFunc(temp)
button.on_click(on_button_clicked)


# # Final Sem

# Extractive Approach Code

# 2. Topic Modelling Approach

# In[217]:


def vectorCreation(combined_list_temp,length):
    vect=CountVectorizer(ngram_range=(1,1),stop_words='english')
    dubby=combined_list_temp
    dtm=vect.fit_transform(dubby)
    lda=LatentDirichletAllocation(n_components=5)
    lda.fit_transform(dtm)
    lda_dtf=lda.fit_transform(dtm)
    sorting=np.argsort(lda.components_)[:,::-1]
    features=np.array(vect.get_feature_names())
    mglearn.tools.print_topics(topics=range(5), feature_names=features,
    sorting=sorting, topics_per_chunk=5, n_words=10)
    result=[]
    Agreement_Topic=np.argsort(lda_dtf[:,0])[::-1]
    for i in Agreement_Topic[:length]:
        #print(dubby[i])
        result.append(dubby[i])
    return result 


# Extractive Approach Evaluation`

# In[129]:


from nltk.translate.bleu_score import corpus_bleu
from rouge import Rouge 


# In[130]:


def listToString(s):  
    str1 = " " 
    return (str1.join(s)) 


# In[131]:


def bleuEvaluation(actual_summary,model_summary):
    actual=list()
    actual_temp=list()
    sen = pd.Series(actual_summary).str.replace("[^a-zA-Z]", " ")
    sen= [s.lower() for s in sen]
    actual_temp.append(nltk.word_tokenize(listToString(sen)))
    actual.append(actual_temp)
    #print(actual)


    model=list()
    sen = pd.Series(model_summary).str.replace("[^a-zA-Z]", " ")
    sen= [s.lower() for s in sen]
    model.append(nltk.word_tokenize(listToString(sen)))
    #print(model)

    score = corpus_bleu(actual,model)
    print("1. Bleu Score:",score)
    print("   ")


# In[132]:


def rougeEvaluation(actual_summary, model_summary):
    rouge = Rouge()
    scores = rouge.get_scores(actual_summary, model_summary)
    print("2. ROUGE score:",scores)
    print("   ")


# In[133]:


def precisionEvalautionSentenceBasis(actual_summary, model_summary):
    x=set(sent_tokenize(actual_summary))
    y=set(sent_tokenize(model_summary))
    precision=(len(x.intersection(y)))/len(y)
    print("3. Precision on basis of common sentences:",precision)
    print("   ")


# In[134]:


def recallEvalautionSentenceBasis(actual_summary, model_summary):
    x=set(sent_tokenize(actual_summary))
    y=set(sent_tokenize(model_summary))
    recall=(len(x.intersection(y)))/len(x)
    print("4. Recall on basis of common sentences:",recall)
    print("   ")


# In[135]:


def evalutionMetrics(actual,model):
    print("   ")
    print("--------------------------------------------------------------------------------------")
    print("Summaries")
    print("--------------------------------------------------------------------------------------")
    print("Actual summary is:")
    actual_summary=actual
#     for sen in actual:
#         if(sen[0].isalpha):
#             sen=sen.capitalize()
#         sen=whitespaceRemoval(sen)
#         actual_summary+=sen+" " 
    print(actual_summary)
    print("      ")
    print("Model Summary is:")
    model_summary=""
    for sen in model:
        if(sen[0].isalpha):
            sen=sen.capitalize()
        sen=whitespaceRemoval(sen)
        model_summary+=sen+". " 
    print(model_summary)
    print("--------------------------------------------------------------------------------------")
    print("Evalaution Metrics:")
    print("--------------------------------------------------------------------------------------")
    bleuEvaluation(actual_summary,model_summary) # 1.
    rougeEvaluation(actual_summary, model_summary) # 2.
    precisionEvalautionSentenceBasis(actual_summary, model_summary) # 3.
    recallEvalautionSentenceBasis(actual_summary, model_summary) # 4.

